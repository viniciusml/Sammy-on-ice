//
//  See LICENSE folder for this template’s licensing information.
//
//  Abstract:
//  Provides supporting functions for setting up a live view.
//

import UIKit
import Foundation
import PlaygroundSupport
import SpriteKit

public class LiveViewController_1_2: LiveViewController, SKSceneDelegate {
    
    var isadded = false
    var isadded2 = false
    var isadded3 = false
    let secondSceneView = LiveViewController_1_1()
    let sceneView = SKScene()
    let skView = SKView()
    let penguinMother = SKSpriteNode(imageNamed: "penguinMother1")
    let eggWithMama = SKSpriteNode(imageNamed: "egg2")
    let termometer = SKSpriteNode(imageNamed: "TermometerNoIce3")
    let termoIndicator = SKSpriteNode(imageNamed: "termoIndicator2")
    let babyPenguin = SKSpriteNode(imageNamed: "babyPenguin1")
    
    let buttonForRetry = UIButton.init(type: UIButton.ButtonType.custom)
    
    let cameraNode = SKCameraNode()
    var lastTouchLocation: CGPoint?
    
    public override func viewDidLoad() {
        super.viewDidLoad()
        sceneView.delegate = self
        
        sceneView.size = CGSize(width: view.bounds.width, height: view.bounds.height)
        skView.frame = CGRect(x: 0, y: 0, width: view.bounds.width, height: view.bounds.height)
        view.addSubview(skView)
        skView.presentScene(sceneView)
        
        secondSceneView.setBackground(scene: self.sceneView)
        secondSceneView.setForeground(scene: self.sceneView)
        setForegroundTwo()
        
        secondSceneView.setEgg(scene: self.sceneView)
        secondSceneView.setPenguinFather(scene: self.sceneView)
        setPenguinMother()
        letItSnow()
        setEggWithMama()
        secondSceneView.egg.isHidden = true
        setCamera()
        zoomToEgg()
        setNormalButton()
        
        secondSceneView.penguinFather.alpha = 0.0
        
        view.isUserInteractionEnabled = false
        run(after: 2) {
            self.termometer.position = CGPoint(x: self.eggWithMama.frame.maxX - 32, y: self.eggWithMama.frame.maxY - 160)
            self.termometer.size = CGSize(width: ((self.sceneView.frame.width / 2) - 10) * 0.5, height: 160 * 0.5)
            self.sceneView.addChild(self.termometer)
            self.termometer.alpha = 0
            let alphaAction = SKAction.fadeAlpha(to: 1, duration: 1)
            self.termometer.run(alphaAction)
            self.termometer.addChild(self.termoIndicator)
        }
        print(termometer.size)
        run(after: 3) {
            self.view.isUserInteractionEnabled = true
        }
        
        termoIndicatorMove()
        
    }
    
    func setForegroundTwo() {
        let foreground2 = SKSpriteNode(imageNamed: "foreground4")
        foreground2.anchorPoint = CGPoint(x: 0.5, y: 0.5)
        foreground2.position = CGPoint(x: sceneView.size.width/2, y: (sceneView.size.height/2) - 50)
        foreground2.size = CGSize(width: sceneView.size.width, height: sceneView.size.height)
        foreground2.zPosition = -2
        sceneView.addChild(foreground2)
    }
    
    func termoIndicatorMove() {
        let moveIndicator = SKAction.moveTo(x: 144, duration: 1)
        let moveBackwards = SKAction.moveTo(x: -144, duration: 1)
        let groupAction = SKAction.sequence([moveIndicator, moveBackwards])
        let repeatAction = SKAction.repeatForever(groupAction)
        termoIndicator.run(repeatAction)
    }
    
    func setCamera() {
        cameraNode.position = CGPoint(x: sceneView.size.width / 2, y: sceneView.size.height / 2)
        sceneView.addChild(cameraNode)
        sceneView.camera = cameraNode
    }
    
    func zoomToEgg() {
        let zoom2 = SKAction.scale(to: 0.6, duration: 2)
        
        let newPosition = CGPoint(x: eggWithMama.position.x + 190, y: eggWithMama.position.y + 70)
        let moveAction = SKAction.move(to: newPosition, duration: 2)
        let group = SKAction.group([zoom2, moveAction])
        cameraNode.run(group)
    }
    
    func setPenguinMother() {
        penguinMother.position = CGPoint(x: (sceneView.frame.maxX / 2) - 120, y: secondSceneView.egg.frame.maxY + 45)
        penguinMother.size = CGSize(width: (secondSceneView.egg.size.width) * 2.7, height: (secondSceneView.egg.size.height) * 2.7)
        penguinMother.zPosition = 1
        penguinMother.name = "egg2"
        sceneView.addChild(penguinMother)
        
    }
    
    func eggHatch() {
        if isadded == false {
            let eggTextureAtlas = SKTextureAtlas(named: "EggHatching")
            
            var firstPart: [SKTexture] = []
            firstPart.append(eggTextureAtlas.textureNamed("eggHatching1"))
            firstPart.append(eggTextureAtlas.textureNamed("eggHatching2"))
            firstPart.append(eggTextureAtlas.textureNamed("eggHatching3"))
            firstPart.append(eggTextureAtlas.textureNamed("eggHatching4"))
            firstPart.append(eggTextureAtlas.textureNamed("eggHatching5"))
            
            var secondPart: [SKTexture] = []
            secondPart.append(eggTextureAtlas.textureNamed("eggHatching6"))
            secondPart.append(eggTextureAtlas.textureNamed("eggHatching7"))
            
            let hatchingOne = SKAction.animate(with: firstPart, timePerFrame: 0.2, resize: false, restore: false)
            let hatchingTwo = SKAction.animate(with: secondPart, timePerFrame: 0.5, resize: false, restore: false)
            
            let inclineOne = SKAction.rotate(byAngle: CGFloat(GLKMathDegreesToRadians(15)), duration: 0.5)
            let inclineTwo = SKAction.rotate(byAngle: CGFloat(GLKMathDegreesToRadians(-30)), duration: 0.5)
            let inclineSequence = SKAction.sequence([inclineOne, inclineTwo, inclineOne])
            let hatchSequence = SKAction.sequence([hatchingOne, hatchingTwo])
            let hatchGroup = SKAction.group([hatchSequence, inclineSequence])
            let eggFade = SKAction.fadeAlpha(to: 0, duration: 1)
            let delay = SKAction.fadeAlpha(to: 1, duration: 1)
            let hatchFadeSequence = SKAction.sequence([hatchGroup, delay, eggFade])
            
            let eggCrackingSound = SKAction.playSoundFileNamed("EggCracking1.mp3", waitForCompletion: false)
            let hatchFadeAndSound = SKAction.group([hatchFadeSequence, eggCrackingSound])
            eggWithMama.run(hatchFadeAndSound)
            isadded = true
        }
    }
    
    public func update(_ currentTime: TimeInterval, for scene: SKScene) {
        
    }
    
    func setEggWithMama() {
        sceneView.addChild(eggWithMama)
        eggWithMama.position = CGPoint(x: penguinMother.frame.minX + 80, y: 190)
        eggWithMama.size = CGSize(width: (eggWithMama.size.width) / 2, height: (eggWithMama.size.height) / 2)
        eggWithMama.zPosition = 3
    }
    
    func setBabyPenguin() {
        if isadded2 == false {
            sceneView.addChild(babyPenguin)
            babyPenguin.position = CGPoint(x: penguinMother.frame.minX + 80, y: 190)
            babyPenguin.size = CGSize(width: eggWithMama.size.width, height: eggWithMama.size.height)
            babyPenguin.alpha = 0
            let exposeBaby = SKAction.fadeAlpha(to: 1, duration: 2)
            let delay = SKAction.fadeAlpha(to: 0, duration: 2)
            let exposeSequence = SKAction.sequence([delay, exposeBaby])
            babyPenguin.run(exposeSequence)
            babyPenguin.zPosition = 3
            isadded2 = true
        }
    }
    
    func setNormalButton() {
        buttonForRetry.setBackgroundImage(UIImage.init(named: "buttonTry"), for: UIControl.State())
        buttonForRetry.setBackgroundImage(UIImage.init(named: "buttonTry"), for: UIControl.State.highlighted)
        buttonForRetry.frame = CGRect(x: 420, y: view.frame.maxY - 370, width: 125, height: 90)
        buttonForRetry.addTarget(self, action:#selector(tryAgainTouched), for: .touchUpInside)
        buttonForRetry.isHidden = true
        view.addSubview(buttonForRetry)
    }
    
    @objc func tryAgainTouched() {
        termoIndicatorMove()
        buttonForRetry.isHidden = true
    }
    
    func sceneTouched(touchLocation:CGPoint) {
        lastTouchLocation = touchLocation
        
        if termoIndicator.position.x > CGFloat(-33) && termoIndicator.position.x < CGFloat(15) {
            eggHatch()
            setBabyPenguin()
            termoIndicator.removeAllActions()
        } else {
            if termoIndicator.position.x < CGFloat(-33) || termoIndicator.position.x > CGFloat(15) {
                termoIndicator.removeAllActions()
                buttonForRetry.isHidden = false
            }
        }
    }
    override public func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let touch = touches.first else {
            return
        }
        let touchLocation = touch.location(in: sceneView)
        sceneTouched(touchLocation: touchLocation)
    }
    override public func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let touch = touches.first else {
            return
        }
        let touchLocation = touch.location(in: sceneView)
        sceneTouched(touchLocation: touchLocation)
    }
    
    func letItSnow() {
        let rect = CGRect(x: 0.0, y: -30.0, width: view.bounds.width, height: 40.0)
        let emitter = CAEmitterLayer()
        emitter.frame = rect
        view.layer.addSublayer(emitter)
        
        emitter.emitterShape = CAEmitterLayerEmitterShape.rectangle
        
        emitter.emitterPosition = CGPoint(x: rect.width/2, y: rect.height/2)
        emitter.emitterSize = rect.size
        
        let emitterCell = CAEmitterCell()
        emitterCell.contents = UIImage(named: "flake1.png")?.cgImage
        
        emitterCell.birthRate = 80
        emitterCell.lifetime = 6
        emitter.emitterCells = [emitterCell]
        emitterCell.yAcceleration = 70.0
        emitterCell.xAcceleration = 3.0
        emitterCell.velocity = 10.0
        emitterCell.emissionLongitude = .pi * -0.5
        emitterCell.velocityRange = 200.0
        emitterCell.emissionRange = .pi * 0.5
    }
    
    override public func receive(_ message: PlaygroundValue) {
        //        Uncomment the following to be able to receive messages from the Contents.swift playground page. You will need to define the type of your incoming object and then perform any actions with it.
        //
        //        guard case .data(let messageData) = message else { return }
        //        do { if let incomingObject = try NSKeyedUnarchiver.unarchiveTopLevelObjectWithData(messageData) as? /*TypeOfYourObject*/ {
        //
        //                //do something with the incoming object from the playground page here
        //
        //            }
        //        } catch let error { fatalError("\(error) Unable to receive the message from the Playground page") }
        
    }
    
    func run(after seconds: Int, completion: @escaping () -> Void) {
        let deadline = DispatchTime.now() + .seconds(seconds)
        DispatchQueue.main.asyncAfter(deadline: deadline) {
            completion()
        }
        
    }
}

