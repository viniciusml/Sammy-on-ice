//
//  See LICENSE folder for this template’s licensing information.
//
//  Abstract:
//  Provides supporting functions for setting up a live view.
//

import UIKit
import Foundation
import PlaygroundSupport
import SpriteKit
import CoreMotion

@available(iOS 11.0, *)
public class LiveViewController_1_3: LiveViewController, SKSceneDelegate {
    
    let motionManager = CMMotionManager()
    var xAcceleration: CGFloat = 0.0
    
    let sceneView = SKScene()
    let skView = SKView()
    let penguinMother = SKSpriteNode(imageNamed: "penguinMother1")
    let eggWithMama = SKSpriteNode(imageNamed: "egg2")
    let babyPenguin = SKSpriteNode(imageNamed: "babyPenguin1")
    let pointsLabel = SKLabelNode()
    let startLabel = SKLabelNode()
    let wellPlayedLabel = SKLabelNode()
    let pointsLabelBackground = SKSpriteNode(imageNamed: "labelBackground1")
    let startLabelBackground = SKSpriteNode(imageNamed: "labelBackground1")
    let wellPlayedLabelBackground = SKSpriteNode(imageNamed: "labelBackground1")
    var pointsAdded = false
    var badFoodAdded = false
    let backgroundFrame = SKSpriteNode()
    let cameraNode = SKCameraNode()
    let physicsWorld = SKPhysicsWorld()
    var fishCaught = 0
    var fakeFishCaught = 0
    
    let emojiOne: Character = "🐟"
    let emojiOneNode = SKLabelNode()
    let emojiTwo: Character = "🐠"
    let emojiTwoNode = SKLabelNode()
    let emojiThree: Character = "🐠"
    let emojiThreeNode = SKLabelNode()
    let emojiFour: Character = "🐟"
    let emojiFourNode = SKLabelNode()
    let emojiFive: Character = "🐙"
    let emojiFiveNode = SKLabelNode()
    let emojiSix: Character = "🦐"
    let emojiSixNode = SKLabelNode()
    let emojiSeven: Character = "🐙"
    let emojiSevenNode = SKLabelNode()
    
    var desiredEmojis: [SKLabelNode] = []
    var undesiredEmojis: [SKLabelNode] = []
    
    var testAcceleration = 0
    var accelerationComparison: Double = 0.0
    
    public override func viewDidLoad() {
        super.viewDidLoad()
        
        sceneView.delegate = self
        
        sceneView.size = CGSize(width: view.bounds.width, height: view.bounds.height)
        skView.frame = CGRect(x: 0, y: 0, width: view.bounds.width, height: view.bounds.height)
        view.addSubview(skView)
        skView.presentScene(sceneView)
        
        setBackground()
        setForeground()
        setBabyPenguin()
        letItSnow()
        createPenguinBackgroundFrame()
        setPointsLabel()
        setStartLabel()
        setYouDidItLabel()
        
        physicsWorld.gravity = CGVector(dx: 0.0, dy: -1.0)
        
        motionManager.accelerometerUpdateInterval = 0.2
        motionManager.startAccelerometerUpdates(to: OperationQueue.current!, withHandler: {
            (accelerometerData: CMAccelerometerData!, error: Error!) in
            let acceleration = accelerometerData.acceleration
            self.xAcceleration = (CGFloat(acceleration.y) * 0.75) + (self.xAcceleration * 0.25)
            
            if (self.motionManager.accelerometerData?.acceleration.x)! < self.accelerationComparison {
                self.testAcceleration = -1
            } else {
                self.testAcceleration = 1
            }
        } )
        
        addEmoji(node: emojiOneNode, emoji: emojiOne)
        addEmoji(node: emojiTwoNode, emoji: emojiTwo)
        addEmoji(node: emojiThreeNode, emoji: emojiThree)
        addEmoji(node: emojiFourNode, emoji: emojiFour)
        addEmoji(node: emojiFiveNode, emoji: emojiFive)
        addEmoji(node: emojiSixNode, emoji: emojiSix)
        addEmoji(node: emojiSevenNode, emoji: emojiSeven)
        
        desiredEmojis = [emojiOneNode, emojiTwoNode, emojiThreeNode, emojiFourNode]
        undesiredEmojis = [emojiSixNode, emojiSevenNode, emojiFiveNode]
        
        sceneView.isPaused = true
        
    }
    
    public func didSimulatePhysics(for scene: SKScene) {
        let returnAlpha = SKAction.fadeIn(withDuration: 0.0)
        let fadeAlpha = SKAction.fadeOut(withDuration: 0.05)
        
        if testAcceleration > 0 {
            babyPenguin.physicsBody?.velocity = CGVector(dx: (xAcceleration * 800.0), dy: babyPenguin.physicsBody!.velocity.dy)
            backgroundFrame.physicsBody?.velocity = CGVector(dx: (xAcceleration * 800.0), dy: babyPenguin.physicsBody!.velocity.dy)
        }
        if testAcceleration < 0 {
            babyPenguin.physicsBody?.velocity = CGVector(dx: -(xAcceleration * 800.0), dy: babyPenguin.physicsBody!.velocity.dy)
            backgroundFrame.physicsBody?.velocity = CGVector(dx: -(xAcceleration * 800.0), dy: babyPenguin.physicsBody!.velocity.dy)
        }
        
//        switch UIDevice.current.orientation {
//        case .landscapeRight:
//            babyPenguin.physicsBody?.velocity = CGVector(dx: (xAcceleration * 800.0), dy: babyPenguin.physicsBody!.velocity.dy)
//            backgroundFrame.physicsBody?.velocity = CGVector(dx: (xAcceleration * 800.0), dy: babyPenguin.physicsBody!.velocity.dy)
//        case .landscapeLeft:
//            babyPenguin.physicsBody?.velocity = CGVector(dx: -(xAcceleration * 800.0), dy: babyPenguin.physicsBody!.velocity.dy)
//            backgroundFrame.physicsBody?.velocity = CGVector(dx: -(xAcceleration * 800.0), dy: babyPenguin.physicsBody!.velocity.dy)
//        default:
//            babyPenguin.physicsBody?.velocity = CGVector(dx: (xAcceleration * 800.0), dy: babyPenguin.physicsBody!.velocity.dy)
//            backgroundFrame.physicsBody?.velocity = CGVector(dx: (xAcceleration * 800.0), dy: babyPenguin.physicsBody!.velocity.dy)
//        }
        
        for node in desiredEmojis {
            if node.position.y < 0.0 {
                let distance = CGFloat(Int(arc4random()%1000))
                let distanceY = CGFloat.random(in: sceneView.frame.maxY + 40..<sceneView.frame.maxY + 600)
                node.position = CGPoint(x: distance, y: distanceY)
                node.run(returnAlpha)
                node.physicsBody?.linearDamping = 8.0
                if node.alpha == 0.0 {
                    fishCaught = fishCaught + 1
                    fakeFishCaught = fakeFishCaught + 1
                    pointsLabel.text = "Points: \(fishCaught)"
                }
            }
            if backgroundFrame.intersects(node) {
                node.run(fadeAlpha)
                node.physicsBody?.linearDamping = 0.0
            }
        }
        
        for node in undesiredEmojis {
            if node.position.y < 0.0 {
                let distance = CGFloat(Int(arc4random()%1000))
                node.position = CGPoint(x: distance, y: sceneView.frame.maxY - 10)
                node.run(returnAlpha)
                badFoodAdded = false
                node.name = "otherName"
            }
            if backgroundFrame.intersects(node) {
                node.alpha = 0.7
                node.name = "badFood"
            }
            if node.frame.maxY < babyPenguin.frame.midY && node.frame.minY > babyPenguin.frame.minY  {
                if node.name == "badFood" {
                    if badFoodAdded == false {
                        badFood()
                    }
                }
            }
        }
        
        if babyPenguin.position.x < sceneView.frame.minX {
            babyPenguin.position = CGPoint(x: sceneView.frame.maxX, y: babyPenguin.position.y)
            backgroundFrame.position = CGPoint(x: sceneView.frame.maxX, y: babyPenguin.position.y)
        } else if (babyPenguin.position.x > sceneView.frame.maxX) {
            babyPenguin.position = CGPoint(x: sceneView.frame.minY, y: babyPenguin.position.y)
            backgroundFrame.position = CGPoint(x: sceneView.frame.minY, y: babyPenguin.position.y)
        }
    }
    
    func badFood() {
        badFoodAdded = true
        let soundAction = SKAction.playSoundFileNamed("grossNoise3.mp3", waitForCompletion: false)
        let stopAction = SKAction.repeat(soundAction, count: 1)

        backgroundFrame.run(stopAction)
        
        let callMamaAtlas = SKTextureAtlas(named: "PenguinSick")
        var actions2: [SKTexture] = []
        actions2.append(callMamaAtlas.textureNamed("babyPenguinSick"))
        
        let callPt1 = SKAction.animate(with: actions2, timePerFrame: 0.1, resize: false, restore: true)
        babyPenguin.run(callPt1)
    }
    
    func setBackground() {
        let background = SKSpriteNode(imageNamed: "clouds4")
        background.anchorPoint = CGPoint(x: 0.5, y: 0.5)
        background.position = CGPoint(x: sceneView.size.width/2, y: sceneView.size.height/2)
        background.size = CGSize(width: sceneView.size.width, height: sceneView.size.height)
        background.zPosition = -1
        sceneView.addChild(background)
    }
    
    func setForeground() {
        let foreground = SKSpriteNode(imageNamed: "foreground4")
        foreground.anchorPoint = CGPoint(x: 0.5, y: 0.5)
        foreground.position = CGPoint(x: sceneView.size.width/2, y: sceneView.size.height/2)
        foreground.size = CGSize(width: sceneView.size.width, height: sceneView.size.height)
        foreground.zPosition = 0
        sceneView.addChild(foreground)
    }
    
    func createPenguinBackgroundFrame() {
        backgroundFrame.position = CGPoint(x: sceneView.frame.midX - 220, y: sceneView.frame.minX + 195)
        backgroundFrame.size = CGSize(width: (babyPenguin.size.width / 1.6), height: (babyPenguin.size.height / 1.6) - 30)
        backgroundFrame.color = .clear
        backgroundFrame.zPosition = 3
        backgroundFrame.physicsBody = SKPhysicsBody(circleOfRadius: babyPenguin.size.width / 2)
        backgroundFrame.physicsBody?.isDynamic = true
        backgroundFrame.physicsBody?.allowsRotation = false
        backgroundFrame.physicsBody?.affectedByGravity = false
        backgroundFrame.physicsBody?.restitution = 1.0
        backgroundFrame.physicsBody?.friction = 0.0
        backgroundFrame.physicsBody?.angularDamping = 0.0
        backgroundFrame.physicsBody?.linearDamping = 0.0
        backgroundFrame.physicsBody?.collisionBitMask = 0
        sceneView.addChild(backgroundFrame)
    }

    func setBabyPenguin() {
        sceneView.addChild(babyPenguin)
        babyPenguin.position = CGPoint(x: sceneView.frame.midX - 220, y: sceneView.frame.minX + 195)
        babyPenguin.size = CGSize(width: (babyPenguin.size.width / 1.6), height: (babyPenguin.size.height / 1.6))
        babyPenguin.zPosition = 3
        
        babyPenguin.physicsBody = SKPhysicsBody(circleOfRadius: babyPenguin.size.width / 2)
        babyPenguin.physicsBody?.isDynamic = true
        babyPenguin.physicsBody?.allowsRotation = false
        babyPenguin.physicsBody?.affectedByGravity = false
        babyPenguin.physicsBody?.restitution = 1.0
        babyPenguin.physicsBody?.friction = 0.0
        babyPenguin.physicsBody?.angularDamping = 0.0
        babyPenguin.physicsBody?.linearDamping = 0.0
        babyPenguin.physicsBody?.collisionBitMask = 0
    }
    
    func letItSnow() {
        let rect = CGRect(x: 0.0, y: -30.0, width: view.bounds.width, height: 40.0)
        let emitter = CAEmitterLayer()
        emitter.frame = rect
        view.layer.addSublayer(emitter)
        
        emitter.emitterShape = CAEmitterLayerEmitterShape.rectangle
        
        emitter.emitterPosition = CGPoint(x: rect.width/2, y: rect.height/2)
        emitter.emitterSize = rect.size
        
        let emitterCell = CAEmitterCell()
        emitterCell.contents = UIImage(named: "flake1.png")?.cgImage
        
        emitterCell.birthRate = 40
        emitterCell.lifetime = 6
        emitter.emitterCells = [emitterCell]
        emitterCell.yAcceleration = 70.0
        emitterCell.xAcceleration = 3.0
        emitterCell.velocity = 10.0
        emitterCell.emissionLongitude = .pi * -0.5
        emitterCell.velocityRange = 200.0
        emitterCell.emissionRange = .pi * 0.5
    }
    
    func setPointsLabel() {
        pointsLabel.fontName = "ArialMT"
        pointsLabel.fontSize = 50
        pointsLabel.fontColor = SKColor.white
        pointsLabel.position = CGPoint(x: 60, y: sceneView.size.height - 120)
        pointsLabel.horizontalAlignmentMode = SKLabelHorizontalAlignmentMode.left
        pointsLabel.text = "Points: \(fishCaught)"
        pointsLabel.alpha = 0.0
        pointsLabel.zPosition = 4
        
        pointsLabelBackground.position = CGPoint(x: pointsLabel.frame.maxX - 85, y: sceneView.size.height - 100)
        pointsLabelBackground.size = CGSize(width: 282, height: 89)
        pointsLabelBackground.alpha = 0.0
        pointsLabelBackground.zPosition = 4
        
        sceneView.addChild(pointsLabelBackground)
        sceneView.addChild(pointsLabel)
    }
    
    func setStartLabel() {
        let labelText = "Tap anywhere\n to start!"
        let attrString = NSMutableAttributedString(string: labelText)
        let paragraphStyle = NSMutableParagraphStyle()
        paragraphStyle.alignment = .center
        let range = NSRange(location: 0, length: labelText.count)
        attrString.addAttribute(NSAttributedString.Key.paragraphStyle, value: paragraphStyle, range: range)
        attrString.addAttributes([NSAttributedString.Key.foregroundColor : UIColor.white, NSAttributedString.Key.font : UIFont.systemFont(ofSize: 30)], range: range)
        
        startLabel.fontName = "ArialMT"
        startLabel.fontSize = 50
        startLabel.fontColor = SKColor.white
        startLabel.position = CGPoint(x: babyPenguin.frame.minX - (startLabel.frame.maxY / 2) - 10, y: babyPenguin.frame.maxY + 100)
        startLabel.horizontalAlignmentMode = SKLabelHorizontalAlignmentMode.left
        startLabel.numberOfLines = 2
        startLabel.attributedText = attrString
        
        startLabelBackground.position = CGPoint(x: startLabel.frame.maxX - 90, y: babyPenguin.frame.maxY + 140)
        startLabelBackground.size = CGSize(width: 250, height: 100)
        
        sceneView.addChild(startLabelBackground)
        sceneView.addChild(startLabel)
    }
    
    func setYouDidItLabel() {
        let winLabelText = "We did it! \n Tap anywhere to\n continue playing."
        let attrString = NSMutableAttributedString(string: winLabelText)
        let paragraphStyle = NSMutableParagraphStyle()
        paragraphStyle.alignment = .center
        let range = NSRange(location: 0, length: winLabelText.count)
        attrString.addAttribute(NSAttributedString.Key.paragraphStyle, value: paragraphStyle, range: range)
        attrString.addAttributes([NSAttributedString.Key.foregroundColor : UIColor.white, NSAttributedString.Key.font : UIFont.systemFont(ofSize: 30)], range: range)
        
        wellPlayedLabel.fontName = "ArialMT"
        wellPlayedLabel.fontSize = 50
        wellPlayedLabel.fontColor = SKColor.white
        wellPlayedLabel.position = CGPoint(x: babyPenguin.frame.minX - (wellPlayedLabel.frame.maxY / 2) - 30, y: babyPenguin.frame.maxY + 100)
        wellPlayedLabel.horizontalAlignmentMode = SKLabelHorizontalAlignmentMode.left
        wellPlayedLabel.numberOfLines = 3
        wellPlayedLabel.attributedText = attrString
        wellPlayedLabel.zPosition = 4
        
        wellPlayedLabelBackground.position = CGPoint(x: wellPlayedLabel.frame.maxX - 110, y: babyPenguin.frame.maxY + 150)
        wellPlayedLabelBackground.size = CGSize(width: 280, height: 180)
        wellPlayedLabelBackground.alpha = 0
        wellPlayedLabel.alpha = 0
        wellPlayedLabelBackground.zPosition = 4
        
        sceneView.addChild(wellPlayedLabelBackground)
        sceneView.addChild(wellPlayedLabel)
    }
    
    public func update(_ currentTime: TimeInterval, for scene: SKScene) {
        forcePenguinUp()
        
        if fakeFishCaught == 5 {
            wellPlayedLabelBackground.alpha = 1
            wellPlayedLabel.alpha = 1
            sceneView.isPaused = true
            fakeFishCaught = fakeFishCaught + 1
        }
    }
    
    func forcePenguinUp() {
        babyPenguin.physicsBody?.affectedByGravity = false
    }
    
    func addEmoji(node: SKLabelNode, emoji: Character) {
        let distanceY = CGFloat.random(in: sceneView.frame.maxY + 40..<sceneView.frame.maxY + 600)
        let distance = CGFloat(Int(arc4random()%1000))
        node.renderEmoji(emoji)
        node.position.y = distanceY
        node.position.x = distance
        node.physicsBody = SKPhysicsBody(circleOfRadius: 50 / 2)
        node.physicsBody?.isDynamic = true
        node.physicsBody?.allowsRotation = false
        node.physicsBody?.restitution = 1.0
        node.physicsBody?.friction = 0.0
        node.physicsBody?.angularDamping = 0.0
        node.physicsBody?.linearDamping = 8.0
        node.physicsBody?.collisionBitMask = 0
        node.zPosition = 3
        sceneView.addChild(node)
    }
    
    func run(after seconds: Int, completion: @escaping () -> Void) {
        let deadline = DispatchTime.now() + .seconds(seconds)
        DispatchQueue.main.asyncAfter(deadline: deadline) {
            completion()
        }
    }
    
    func sceneTouched(touchLocation:CGPoint) {
        let fadeOut = SKAction.fadeOut(withDuration: 0.3)
        let fadeIn = SKAction.fadeIn(withDuration: 0.3)
        
        if sceneView.isPaused == true {
            startLabelBackground.run(fadeOut)
            startLabel.run(fadeOut)
            pointsLabelBackground.run(fadeIn)
            pointsLabel.run(fadeIn)
            wellPlayedLabelBackground.alpha = 0
            wellPlayedLabel.alpha = 0
            sceneView.isPaused = false
        }
    }
    
    override public func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let touch = touches.first else {
            return
        }
        let touchLocation = touch.location(in: sceneView)
        sceneTouched(touchLocation: touchLocation)
    }
    
    override public func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let touch = touches.first else {
            return
        }
        let touchLocation = touch.location(in: sceneView)
        sceneTouched(touchLocation: touchLocation)
    }
    
    override public func receive(_ message: PlaygroundValue) {
        //        Uncomment the following to be able to receive messages from the Contents.swift playground page. You will need to define the type of your incoming object and then perform any actions with it.
        //
        //        guard case .data(let messageData) = message else { return }
        //        do { if let incomingObject = try NSKeyedUnarchiver.unarchiveTopLevelObjectWithData(messageData) as? /*TypeOfYourObject*/ {
        //
        //                //do something with the incoming object from the playground page here
        //
        //            }
        //        } catch let error { fatalError("\(error) Unable to receive the message from the Playground page") }
        
    }
}

extension SKLabelNode {
    func renderEmoji(_ emoji: Character) {
        fontSize = 50
        text = String(emoji)
        
        verticalAlignmentMode = .center
        horizontalAlignmentMode = .center
    }
}
