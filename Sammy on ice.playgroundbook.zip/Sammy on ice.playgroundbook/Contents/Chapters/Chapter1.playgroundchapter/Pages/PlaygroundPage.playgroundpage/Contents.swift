//#-hidden-code
//
//  See LICENSE folder for this template’s licensing information.
//
//  Abstract:
//  The Swift file containing the source code edited by the user of this playground book.
//


//Messaging from Page to Live View:
import Foundation
import PlaygroundSupport
//Use the call below to send a message with an object to the LiveView of this page. Import Foundation is required.

//Give hints and final solution:
//PlaygroundPage.current.assessmentStatus = .fail(
//hints: [
//"You could [...].",
//"Try also [...]."
//],
//solution:
//"Do [...]."
//)



// Completion of user-entered code:
//Use //#-code-completion syntax to allow only specified code to be entered by the user. (info here: https://developer.apple.com/documentation/swift_playgrounds/customizing_the_completions_in_the_shortcut_bar)

func call(_ type: FunctionType) {
    sendValue(.string(type.rawValue))
    if type == .mom {
        PlaygroundPage.current.assessmentStatus = .pass(message: "You did it! Now that she is here, move the egg to her.")
    } else {
        PlaygroundPage.current.assessmentStatus = .fail(hints: ["Try calling 'mom' and see what happens"], solution: "call(.mom)")
    }
}

//#-code-completion(mom, show)
//#-code-completion(dad, show)
//#-code-completion(other, show)
//#-end-hidden-code

/*:
 
 #### Before my birth
 
 Emperor penguins consider the breeding season very special, since we live in a unique environment, where the extreme cold and long distances are the main challenges we must face.
 
 However, with my **parent's bravery** and **your help** I am sure these obstacles will become easy and fun!
 
 As you can see, I was still inside the egg, and my dad was taking care of me, because after my mom layed it, she went on a hunting trip with the other mothers.
 
 #### Mom's arrival
 
 After she gathered some food, mom came back to join us. Dad needed to call her, so she was able to find us in the middle of all the other penguin fathers around us. That's where you can help us. Complete the action below correctly, so dad can **call mom**.
 */


 call(./*#-editable-code*/dad/*#-end-editable-code*/)

 
//:Once she arrived, dad needed to leave to get some food for him. To do that, he carefully rolled the egg to mom. This way I was kept warm all the time. Help them roll the egg by **dragging it from dad to mom**. Just remember to be carefull, because the egg shell is very sensitive. When the egg got rolled to mom, I remained with her until it was ready to hatch.



