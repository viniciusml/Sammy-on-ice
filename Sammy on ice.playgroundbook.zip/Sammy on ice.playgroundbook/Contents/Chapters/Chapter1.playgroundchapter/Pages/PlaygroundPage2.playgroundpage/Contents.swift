
/*:
 #### Getting ready to hatch
 
 Now that mom got the egg and was keeping me warm, the time to break free from this egg arrived and I could finally see for the first time this beautiful land that we inhabit.
 
 Penguins breed in the winter, and, during this season, the temperature might be as low as -40°F (-40°C). However, in order to hatch the eggs safely, penguins father and mother keep them as close to their bodies as possible.
 This keeps the eggs in temperatures ranging from **86°F (30°C)** to **104°F (40°C)**.
 
 Tap the screen to **stop the pointer** in the correct place indicated in the thermometer to see what happens.
 
 #### The world outside the egg
 
 The first time I opened my eyes it took me a few seconds to get used to the clarity, and then I saw it. White fields of ice, reaching as far as the eyes can see. And when I looked up, there she was. My mom, welcoming me with love. She said our world is much more than I can imagine, and that she hopes I can experience all its beauty when I am ready.
 */




