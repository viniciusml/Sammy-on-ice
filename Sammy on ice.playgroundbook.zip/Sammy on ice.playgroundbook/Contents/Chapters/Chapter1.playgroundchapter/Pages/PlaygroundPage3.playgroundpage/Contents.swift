
/*:
 #### Feeding time
 
 As soon as I began discovering this amazing environment, I met the other baby penguins and started exploring around. But these adventures **made me hungry!**
 
 Dad and mom brought me food from their hunting trip, dropped it from their beak and I had to catch it. Since I am still very small compared to their size, sometimes I have to move a little to get the food. I like eating silver fish (🐠) and cob fish (🐟), but I don't enjoy eating octopus (🐙) and shrimp (🦐). So, I try not to catch these.
 
 Can you join me on this task?
 
 **Tilt your device to left and right** to see me sliding, and help me catch the prey I like and avoid the ones I don't. If you want, you can use the full screen to get the most out of this experience.
 
 Day by day, I grew confident with the help of my family, and this way I could share my story with you. I hope you enjoyed it and I invite you to discover more about our beautiful land and our lifestyle!
 */

